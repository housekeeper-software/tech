#!/usr/local/python/bin/python
# -*- coding: UTF-8 -*-
from __future__ import with_statement
from datetime import datetime
from struct import *
import subprocess
import json
import os
import hashlib
import sys
import logging
import time
import threading
import fcntl

AppDir = '/outdoor/app'
ShadowDir = '/data/jingxi/shadow'
AppBinFile = '/outdoor/app/outdoorapp'
ScriptName = 'script'  # 启动脚本
AppName = 'app'  # 主程序
LogFile = '/oem/startup.log'

Log_Format = "%(levelname)s %(asctime)s - %(message)s"


def extract_file(source_fle, target_dir):
    """解压文件到指定的目录"""
    p = subprocess.Popen(['tar', '-zxvf', source_fle, '-C',
                         target_dir], stderr=subprocess.STDOUT, stdout=None)
    return p.wait()


def read_version(f):
    """从指定文件读取版本号"""
    try:
        with open(f, 'rb') as fp:
            content = fp.read()
            return content.replace('\n', '').replace('\r', '')
    except Exception as err:
        logging.warning("read file error: {0},{0}".format(f, err))
        return ""


def md5sum(f, read_size=4096):
    """计算文件MD5"""
    try:
        m = hashlib.md5()
        with open(f, 'rb') as fd:
            data = fd.read(read_size)
            while data:
                m.update(data)
                data = fd.read(read_size)
            else:
                return m.hexdigest()
    except Exception as err:
        logging.warning("md5sum file error:{}".format(err))
        return ""


def is_need_update(d):
    """判断版本号以决定是否需要升级"""
    logging.info("judge version")
    name = d['name']
    version = d['version']
    if name == AppName:
        version_file = os.path.join(AppDir, 'version')

        if not (os.path.exists(version_file)):
            logging.info("{} not exist, must update".format(version_file))
            return True  # 文件不存在
            # 读取本地版本
        local_version = read_version(version_file)
        logging.info("name: {}, local version: {}, server version: {}".format(
            name, local_version, version))

        if local_version.lower() == version.lower():
            logging.info("version equal,should not update")
            return False
        logging.info(
            "{} will be update for local version not match".format(name))
        return True  # 本地版本和shadow版本不同,需要升级
    elif name == ScriptName:
        if ScriptVersion.lower() == version.lower():
            logging.info("version equal,should not update")
            return False
        else:
            logging.info(
                "{} will be update for local version not match".format(name))
            return True  # 本地版本和shadow版本不同,需要升级


def verify_hash(d):
    print("judge hash")
    try:
        filename = d['filename']
        digest = d['hash']
        source_file = os.path.join(ShadowDir, filename)
        logging.info("filename: {}, hash: {}, localpath: {}".format(
            filename, digest, source_file))
        if not (os.path.exists(source_file)):
            logging.warning("{} file not found".format(source_file))
            return False
        file_hash = md5sum(source_file)
        if file_hash is None or file_hash.lower() != digest.lower():
            logging.warning("{} file hash error: shadow hash:{}, file hash:{}".format(
                source_file, digest, file_hash))
            return False
        print("hash correct")
        return True
    except Exception as err:
        logging.warning("read file error: {}".format(err))
        return False


def process_file(d):
    # 先从版本号判断是否需要升级,因为解压比较耗时
    if not (is_need_update(d)):
        return False

    # 判断shadow中的文件是否完整
    if not (verify_hash(d)):
        return False

    try:
        filename = d['filename']
        name = d['name']
        version = d['version']
        source_file = os.path.join(ShadowDir, filename)
        logging.info("process [{}] ,filename: {}, version: {}, path: {}".format(
            name, filename, version, source_file))
        if not (os.path.exists(source_file)):
            logging.warning("{} not found, can not update".format(source_file))
            return False

        if name == AppName:
            target_dir = os.path.join(AppDir)
            print("target path: {}".format(target_dir))
            if not (os.path.exists(target_dir)):
                os.makedirs(target_dir)
            ret = extract_file(source_file, target_dir)
            if ret == 0:
                # 解压成功,我们创建版本号
                with open(os.path.join(target_dir, 'version'), mode='w') as fp:
                    fp.write(version)
                logging.info("{} update success".format(name))
            else:
                logging.warning(
                    "{} update failed,tar return code:{}".format(name, ret))
            return True
        else:
            logging.warning("name : {} not support".format(name))

    except Exception as err:
        logging.warning("process file error: {}".format(err))
        return False


def record(code):
    """记录重启信息"""
    dt = datetime.now()
    with open('/oem/restart.txt', mode='a') as fp:
        fp.write('outdoorapp restart :{0}, code:{1}'.format(
            dt.strftime('%Y-%m-%d %H:%M:%S'), code))
        fp.write('\n')


class Update:
    _items = []
    _model = ""

    def __init__(self):
        pass

    def read_shadow(self):
        """读取本机适配的升级信息"""
        logging.info("read upgrade from shadow")
        filename = os.path.join(ShadowDir, "upgrade.json")
        if not (os.path.exists(filename)):
            logging.warning("shadow file not exist: {}".format(filename))
            return False
        try:
            with open(filename, 'r') as fp:
                root = json.loads(fp.read().decode('utf-8'))
                content = root['content']
                for element in content:
                    if element['scheme'].lower() == 'app'.lower():
                        model = element['model']
                        name = element['name']
                        version = element['version']
                        logging.info("model: {}, name: {}, version: {}".format(
                            model, name, version))
                        if len(model) == 0:
                            logging.warning("model is empty")
                            continue
                        if model.lower() != self._model.lower():
                            logging.warning("model not equal")
                            continue
                        if len(version) == 0:
                            logging.warning("version is empty")
                            continue
                        if name.lower() != AppName:
                            logging.warning("name not support")
                            continue
                        logging.info("add to upgrade list")
                        self._items.append(element)      
                if not self._items:
                    logging.warning("No items were added to the upgrade list.")
                    return False
                return True
        except Exception as err:
            logging.warning("read shadow.json error:{}".format(err))
            return False

    def read_model(self):
        """读取本机model"""
        logging.info("read local model")
        filename = os.path.join(AppDir, "res", "app.json")
        if not (os.path.exists(filename)):
            return False
        try:
            with open(filename, 'r') as fp:
                root = json.loads(fp.read().decode('utf-8'))
                self._model = root['model']
                logging.info("local model = {}".format(self._model))
                return True
        except Exception as err:
            logging.warning("read app.json error:{0}".format(err))
            return False

    def process_update(self):
        for i in self._items:
            process_file(i)


def update():
    """执行升级操作"""
    logging.info("start update")
    u = Update()
    ret = u.read_model()
    if ret:
        ret = u.read_shadow()
        if ret:
            u.process_update()


def run():
    """启动主程序"""
    logging.info("start outdoorapp")
    process = subprocess.Popen(
        AppBinFile, shell=False, cwd=os.path.dirname(AppBinFile))
    code = process.wait()
    record(code)
    return code


def main():
    while True:
        update()
        if not (os.path.exists(AppBinFile)):
            logging.error('not found {}'.format(AppBinFile))
            break
        code = run()
        if code == 100:
            logging.info("reboot")
            break  # 重启设备
        else:
            time.sleep(2)


if __name__ == '__main__':
    if os.path.exists(LogFile):
        size = os.path.getsize(LogFile)
        if size > 1024 * 1024:
            os.remove(LogFile)
    logging.basicConfig(
        filename=LogFile, format=Log_Format, level=logging.INFO)
    main()
