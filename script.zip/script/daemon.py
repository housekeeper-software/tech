#!/usr/local/python/bin/python
# -*- coding: UTF-8 -*-
from __future__ import with_statement
from datetime import datetime
from struct import *
import subprocess
import os
import sys
import logging
import time

LogFile = '/tmp/daemon.log'
Log_Format = "%(levelname)s %(asctime)s - %(message)s"


def is_number(s):
    try:
        int(s)
        return True
    except ValueError:
        pass
    return False


def run(cmd, startup_dir, params):
    parameters = [cmd] + params
    process = subprocess.Popen(parameters, shell=False,cwd=startup_dir)
    code = process.wait()
    return code


def main(argv):
    num_args = len(argv)
    if num_args < 3:
        logging.error("cmdline parameters not enough,[exitcode,app,app startup path,app parameters...]")
        exit(1)
    if not is_number(argv[0]):
        logging.error("first parameter must be number,like -1,0,100")
        exit(1)
    exit_code = int(argv[0])
    while True:
        code = run(argv[1], argv[2], argv[3:])
        logging.info("{} exit code[{}]".format(argv[1], code))
        if exit_code > 0:
            if code == exit_code:
                break
        time.sleep(2)


if __name__ == '__main__':
    logging.basicConfig(filename=LogFile, format=Log_Format, level=logging.INFO)
    logging.info("argv{}".format(sys.argv[1:]))
    main(sys.argv[1:])
