#!/bin/bash

function docker_install()
{
	echo "check docker exist......"
	docker -v
    if [ $? -eq  0 ]; then
        echo "docker installed already"
    else
    	echo "prepare install docker..."
        curl -fsSL https://get.docker.com | bash -s docker --mirror Aliyun
        echo "docker install done"
    fi
}

if [ ! -n "$1" ]; then
    echo "please input public ip addr"
    exit
fi

cp sources.list /etc/apt/sources.list

apt -y update
apt-get -y install apt-utils gnupg ca-certificates apt-transport-https procps net-tools wget curl vim unzip tcpdump m4  git build-essential
cp sysctl.conf /etc/sysctl.conf
sysctl -p

mkdir -p /etc/docker
cp daemon.json /etc/docker/daemon.json

docker_install

curl -L https://github.com/docker/compose/releases/latest/download/docker-compose-Linux-x86_64 > /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

docker network create --driver bridge --subnet=172.18.0.0/16 --gateway=172.18.1.1 mynet

docker pull mysql:5.7.34
docker login -u jingxi@starsoftcomm.com -p Jx5100061000 registry.cn-shanghai.aliyuncs.com
docker pull registry.cn-shanghai.aliyuncs.com/smartlife-docker/opensips:3.4.5

m4 rtpproxy.service.m4 > rtpproxy.service
m4 ../mysql/docker-compose.yaml.m4 > ../mysql/docker-compose.yaml
m4 ../opensips/conf/opensips-cli.cfg.m4 > ../opensips/conf/opensips-cli.cfg
m4 ../opensips/conf/opensips.cfg.m4 > ../opensips/conf/opensips.cfg








