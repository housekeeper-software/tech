#!/bin/bash

docker run -d --name=sip --network mynet --ip=172.18.12.1 -p 5060:5060 -p 5060:5060/udp registry.cn-shanghai.aliyuncs.com/smartlife-docker/opensips:3.4.5
docker cp ../opensips/conf/opensips-cli.cfg sip:/etc/opensips/opensips-cli.cfg
sleep 10
docker exec sip sh -c "opensips-cli -x database create"
docker exec sip sh -c "opensips-cli -x user add 1001 123456"
docker exec sip sh -c "opensips-cli -x user add 1002 123456"
docker stop sip
docker rm sip