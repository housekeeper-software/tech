#!/bin/bash
curdir=$PWD

mkdir -p /build/source
cd /build/source
git clone -b v3.0.1 https://github.com/sippy/rtpproxy.git
git -C rtpproxy submodule update --init --recursive
cd rtpproxy
./configure
make clean all
make install

cd $curdir
cp rtpproxy.service /etc/systemd/system/rtpproxy.service
chmod 644 /etc/systemd/system/rtpproxy.service

systemctl daemon-reload
systemctl enable rtpproxy
systemctl start rtpproxy