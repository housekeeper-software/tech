#!/bin/bash

docker run -d --name=kamailio --network mynet --ip=172.18.12.1 -p 18888:18888 -p 18888:18888/udp registry.cn-shanghai.aliyuncs.com/smartlife-docker/kamailio:5.8
docker cp ../kamailio/conf/kamctlrc kamailio:/etc/kamailio/kamctlrc
docker cp ../kamailio/conf/kamdbctl.mysql kamailio:/usr/lib/x86_64-linux-gnu/kamailio/kamctl/kamdbctl.mysql


#docker exec -it kamailio /bin/bash
# 执行以下命令
#kamdbctl create
#kamctl add 1001 123456
#kamctl add 1002 123456
#kamctl add 1003 123456
#kamctl add 1004 123456
#kamctl add 1005 123456
#kamctl add 1006 123456
#kamctl add 1007 123456
#kamctl add 1008 123456
#kamctl add 1009 123456
#kamctl add 1010 123456

#docker stop kamailio
#docker rm kamailio