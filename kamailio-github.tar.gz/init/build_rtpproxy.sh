#!/bin/bash
curdir=$PWD

cd ../rtpproxy
#git clone -b v3.0.1 https://github.com/sippy/rtpproxy.git
#git -C rtpproxy submodule update --init --recursive
mkdir source
tar zxvf rtpproxy-3.0.1-source.tar.gz -C source
cd source
./configure
make clean all
make install

rm -rf source

cd $curdir
cp rtpproxy.service /etc/systemd/system/rtpproxy.service
chmod 644 /etc/systemd/system/rtpproxy.service

systemctl daemon-reload
systemctl enable rtpproxy
systemctl start rtpproxy